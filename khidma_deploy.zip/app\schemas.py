from typing import Optional
from pydantic import BaseModel, Field, field_validator

class CustomerCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=150)
    phone: str = Field(..., min_length=7, max_length=50)
    notes: Optional[str] = None

    @field_validator("name")
    def validate_name(cls, v: str) -> str:
        clean = v.strip()
        if not clean:
            raise ValueError("يرجى إدخال اسم العميل بشكل صحيح")
        return clean

    @field_validator("phone")
    def validate_phone(cls, v: str) -> str:
        clean = v.strip()
        if not clean:
            raise ValueError("يرجى إدخال رقم هاتف العميل")
        return clean


class OrderCreate(BaseModel):
    customer_id: Optional[int] = None
    new_customer_name: Optional[str] = None
    new_customer_phone: Optional[str] = None
    title: str = Field(..., min_length=2, max_length=255)
    amount: float = Field(..., ge=0)
    status: str = Field(default="جديد")

    @field_validator("title")
    def validate_title(cls, v: str) -> str:
        clean = v.strip()
        if not clean:
            raise ValueError("يرجى إدخال تفاصيل الطلب بشكل واضح")
        return clean

    @field_validator("amount")
    def validate_amount(cls, v: float) -> float:
        if v < 0:
            raise ValueError("مبلغ الطلب لا يمكن أن يكون سالباً")
        return round(float(v), 2)

    @field_validator("status")
    def validate_status(cls, v: str) -> str:
        valid_statuses = ["جديد", "قيد التنفيذ", "مكتمل"]
        if v not in valid_statuses:
            raise ValueError(f"حالة الطلب غير صالحة. الحالات المسموحة: {', '.join(valid_statuses)}")
        return v


class TransactionCreate(BaseModel):
    type: str = Field(...)
    category: Optional[str] = None
    amount: float = Field(..., gt=0)
    description: Optional[str] = None

    @field_validator("type")
    def validate_type(cls, v: str) -> str:
        clean = v.strip()
        if clean not in ["مبيعات", "مصروفات"]:
            raise ValueError("نوع العملية يجب أن يكون إما 'مبيعات' أو 'مصروفات'")
        return clean

    @field_validator("amount")
    def validate_amount(cls, v: float) -> float:
        if v <= 0:
            raise ValueError("يجب أن يكون المبلغ أكبر من الصفر")
        return round(float(v), 2)
