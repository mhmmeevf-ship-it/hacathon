from typing import Optional, List, Dict, Any
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import func, or_
from app.models import Customer, Order, Transaction
from app.schemas import CustomerCreate, OrderCreate, TransactionCreate

def get_dashboard_stats(db: Session) -> Dict[str, Any]:
    """Calculate core business KPIs strictly deterministically with Python & SQL."""
    total_orders = db.query(func.count(Order.id)).scalar() or 0
    active_orders = db.query(func.count(Order.id)).filter(Order.status.in_(["جديد", "قيد التنفيذ"])).scalar() or 0
    completed_orders = db.query(func.count(Order.id)).filter(Order.status == "مكتمل").scalar() or 0

    total_revenue = db.query(func.sum(Transaction.amount)).filter(Transaction.type == "مبيعات").scalar() or 0.0
    total_expenses = db.query(func.sum(Transaction.amount)).filter(Transaction.type == "مصروفات").scalar() or 0.0

    net_profit = total_revenue - total_expenses

    return {
        "total_orders": total_orders,
        "active_orders": active_orders,
        "completed_orders": completed_orders,
        "total_revenue": round(total_revenue, 2),
        "total_expenses": round(total_expenses, 2),
        "net_profit": round(net_profit, 2)
    }

def get_recent_orders(db: Session, limit: int = 6) -> List[Order]:
    return db.query(Order).options(joinedload(Order.customer)).order_by(Order.created_at.desc()).limit(limit).all()

def get_orders(db: Session, status: Optional[str] = None) -> List[Order]:
    query = db.query(Order).options(joinedload(Order.customer))
    if status and status != "الكل":
        query = query.filter(Order.status == status)
    return query.order_by(Order.created_at.desc()).all()

def create_order(db: Session, data: OrderCreate) -> Order:
    customer_id = data.customer_id

    # If quick-adding a new customer from the order form
    if not customer_id:
        if not data.new_customer_name or not data.new_customer_phone:
            raise ValueError("يرجى اختيار عميل مسجل أو إدخال اسم ورقم هاتف العميل الجديد")
        
        # Check if customer with this phone already exists
        existing_cust = db.query(Customer).filter(Customer.phone == data.new_customer_phone.strip()).first()
        if existing_cust:
            customer_id = existing_cust.id
        else:
            new_cust = Customer(
                name=data.new_customer_name.strip(),
                phone=data.new_customer_phone.strip(),
                notes="تمت الإضافة السريعة مع طلب جديد"
            )
            db.add(new_cust)
            db.flush()
            customer_id = new_cust.id

    order = Order(
        customer_id=customer_id,
        title=data.title.strip(),
        amount=round(data.amount, 2),
        status=data.status
    )
    db.add(order)
    db.flush()

    # Automatic recording of completed order revenue into transactions
    if order.status == "مكتمل" and order.amount > 0:
        tx = Transaction(
            type="مبيعات",
            category="مبيعات طلبات",
            amount=order.amount,
            description=f"إيراد الطلب #{order.id}: {order.title}"
        )
        db.add(tx)

    db.commit()
    db.refresh(order)
    return order

def update_order_status(db: Session, order_id: int, new_status: str) -> Optional[Order]:
    valid_statuses = ["جديد", "قيد التنفيذ", "مكتمل"]
    if new_status not in valid_statuses:
        raise ValueError(f"حالة غير صالحة. الحالات المسموحة: {', '.join(valid_statuses)}")

    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        return None

    old_status = order.status
    order.status = new_status

    # If marked as completed and wasn't completed before, record into transactions if not already recorded
    if new_status == "مكتمل" and old_status != "مكتمل" and order.amount > 0:
        desc_marker = f"إيراد الطلب #{order.id}:"
        existing_tx = db.query(Transaction).filter(
            Transaction.type == "مبيعات",
            Transaction.description.like(f"{desc_marker}%")
        ).first()

        if not existing_tx:
            tx = Transaction(
                type="مبيعات",
                category="مبيعات طلبات",
                amount=order.amount,
                description=f"إيراد الطلب #{order.id}: {order.title}"
            )
            db.add(tx)

    db.commit()
    db.refresh(order)
    return order

def get_customers(db: Session, search: Optional[str] = None) -> List[Dict[str, Any]]:
    query = db.query(Customer)
    if search:
        search_term = f"%{search.strip()}%"
        query = query.filter(or_(Customer.name.ilike(search_term), Customer.phone.ilike(search_term)))

    customers = query.order_by(Customer.created_at.desc()).all()
    results = []

    for cust in customers:
        orders_count = len(cust.orders)
        total_spent = sum(o.amount for o in cust.orders if o.status == "مكتمل")
        results.append({
            "id": cust.id,
            "name": cust.name,
            "phone": cust.phone,
            "notes": cust.notes,
            "created_at": cust.created_at,
            "orders_count": orders_count,
            "total_spent": round(total_spent, 2),
            "orders": cust.orders
        })
    return results

def get_customer_by_id(db: Session, customer_id: int) -> Optional[Dict[str, Any]]:
    cust = db.query(Customer).filter(Customer.id == customer_id).first()
    if not cust:
        return None
    orders_count = len(cust.orders)
    total_spent = sum(o.amount for o in cust.orders if o.status == "مكتمل")
    return {
        "id": cust.id,
        "name": cust.name,
        "phone": cust.phone,
        "notes": cust.notes,
        "created_at": cust.created_at,
        "orders_count": orders_count,
        "total_spent": round(total_spent, 2),
        "orders": cust.orders
    }

def create_customer(db: Session, data: CustomerCreate) -> Customer:
    existing = db.query(Customer).filter(Customer.phone == data.phone.strip()).first()
    if existing:
        raise ValueError("رقم الهاتف مسجل مسبقاً لعميل آخر")

    customer = Customer(
        name=data.name.strip(),
        phone=data.phone.strip(),
        notes=data.notes.strip() if data.notes else None
    )
    db.add(customer)
    db.commit()
    db.refresh(customer)
    return customer

def get_transactions(db: Session, limit: int = 100) -> List[Transaction]:
    return db.query(Transaction).order_by(Transaction.created_at.desc()).limit(limit).all()

def create_transaction(db: Session, data: TransactionCreate) -> Transaction:
    tx = Transaction(
        type=data.type,
        category=data.category.strip() if data.category else ("مبيعات عامة" if data.type == "مبيعات" else "مصروفات عامة"),
        amount=round(data.amount, 2),
        description=data.description.strip() if data.description else None
    )
    db.add(tx)
    db.commit()
    db.refresh(tx)
    return tx
