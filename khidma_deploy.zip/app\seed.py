from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from app.models import Customer, Order, Transaction

def seed_data_if_empty(db: Session):
    """Populates realistic Arabic initial dummy data if the database is newly created."""
    customer_count = db.query(Customer).count()
    if customer_count > 0:
        return  # Data already exists

    print("🌱 جاري تهيئة قاعدة البيانات ببيانات أولية تجريبية واقعية لـ «خِدمة»...")

    # 1. Customers
    c1 = Customer(
        name="عبدالله بن فهد العتيبي",
        phone="0501234567",
        notes="عميل دائم - يفضل الورق الفاخر والتسليم السريع",
        created_at=datetime.utcnow() - timedelta(days=12)
    )
    c2 = Customer(
        name="سارة بنت محمد الشمري",
        phone="0559876543",
        notes="مديرة تسويق - شركة تمكين للحلول الرقمية",
        created_at=datetime.utcnow() - timedelta(days=9)
    )
    c3 = Customer(
        name="مؤسسة الابتكار للتجارة",
        phone="0543322110",
        notes="حساب تجاري - طلبات دورية لمواد الدعاية والبروشورات",
        created_at=datetime.utcnow() - timedelta(days=7)
    )
    c4 = Customer(
        name="خالد بن عبدالعزيز الحربي",
        phone="0567788990",
        notes="مؤسس كافيه أروما - مشاريع مستمرة لتطوير الهوية والعلب",
        created_at=datetime.utcnow() - timedelta(days=5)
    )
    c5 = Customer(
        name="نوف بنت صالح القحطاني",
        phone="0531122334",
        notes="منسقة معارض ومؤتمرات سنوية",
        created_at=datetime.utcnow() - timedelta(days=3)
    )

    db.add_all([c1, c2, c3, c4, c5])
    db.flush()

    # 2. Orders
    o1 = Order(
        customer_id=c3.id,
        title="طباعة وتغليف 1,000 بروشور تعريفي مقاس A4 مطفي",
        amount=850.0,
        status="مكتمل",
        created_at=datetime.utcnow() - timedelta(days=6)
    )
    o2 = Order(
        customer_id=c4.id,
        title="تصميم وطباعة هوية بصرية متكاملة (شعار، بطاقات، أكياس)",
        amount=2400.0,
        status="مكتمل",
        created_at=datetime.utcnow() - timedelta(days=4)
    )
    o3 = Order(
        customer_id=c1.id,
        title="طباعة دفاتر فواتير وسندات قبض رسمية (10 دفاتر مخصصة)",
        amount=450.0,
        status="مكتمل",
        created_at=datetime.utcnow() - timedelta(days=3)
    )
    o4 = Order(
        customer_id=c4.id,
        title="طباعة 500 كوب كرتوني معزول بشعار الكافيه البارز",
        amount=1200.0,
        status="قيد التنفيذ",
        created_at=datetime.utcnow() - timedelta(days=2)
    )
    o5 = Order(
        customer_id=c2.id,
        title="لوحة إعلانية خارجية أكريليك مع إضاءة LED مقاس 2×1 متر",
        amount=3100.0,
        status="جديد",
        created_at=datetime.utcnow() - timedelta(days=1)
    )
    o6 = Order(
        customer_id=c5.id,
        title="رول اب ستاند إعلاني متحرك مقاس 85×200 سم للمؤتمر",
        amount=600.0,
        status="جديد",
        created_at=datetime.utcnow() - timedelta(hours=4)
    )

    db.add_all([o1, o2, o3, o4, o5, o6])
    db.flush()

    # 3. Financial Transactions
    t1 = Transaction(
        type="مبيعات",
        category="مبيعات طلبات",
        amount=850.0,
        description=f"إيراد الطلب #{o1.id}: {o1.title}",
        created_at=datetime.utcnow() - timedelta(days=6)
    )
    t2 = Transaction(
        type="مبيعات",
        category="مبيعات طلبات",
        amount=2400.0,
        description=f"إيراد الطلب #{o2.id}: {o2.title}",
        created_at=datetime.utcnow() - timedelta(days=4)
    )
    t3 = Transaction(
        type="مبيعات",
        category="مبيعات طلبات",
        amount=450.0,
        description=f"إيراد الطلب #{o3.id}: {o3.title}",
        created_at=datetime.utcnow() - timedelta(days=3)
    )
    t4 = Transaction(
        type="مبيعات",
        category="خدمات فورية",
        amount=350.0,
        description="خدمة تصميم وتعديل شعار فوري لعميل زائر",
        created_at=datetime.utcnow() - timedelta(days=2)
    )

    t5 = Transaction(
        type="مصروفات",
        category="مواد خام ومستلزمات",
        amount=950.0,
        description="شراء 5 كراتين ورق كوشيه مقاس A4 و A3 فاخر",
        created_at=datetime.utcnow() - timedelta(days=6)
    )
    t6 = Transaction(
        type="مصروفات",
        category="أحبار وصيانة",
        amount=420.0,
        description="تعبئة حبر أزرق وأسود لطابعة الليزر وصيانة أسطوانة السحب",
        created_at=datetime.utcnow() - timedelta(days=4)
    )
    t7 = Transaction(
        type="مصروفات",
        category="برمجيات واشتراكات",
        amount=300.0,
        description="اشتراك شهري في حزمة برامج التصميم السحابية",
        created_at=datetime.utcnow() - timedelta(days=2)
    )
    t8 = Transaction(
        type="مصروفات",
        category="فواتير ومرافق",
        amount=250.0,
        description="سداد فاتورة الإنترنت فائق السرعة الخاص بالمعمل",
        created_at=datetime.utcnow() - timedelta(days=1)
    )

    db.add_all([t1, t2, t3, t4, t5, t6, t7, t8])
    db.commit()
    print("✅ تم بنجاح زرع البيانات الأولية بنمط عربي واقعي.")
