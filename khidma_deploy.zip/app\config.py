import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env file securely from project root
BASE_DIR = Path(__file__).resolve().parent.parent
ENV_PATH = BASE_DIR / ".env"

if ENV_PATH.exists():
    load_dotenv(dotenv_path=ENV_PATH)
else:
    load_dotenv()

class Settings:
    PROJECT_NAME: str = "خِدمة | Khidma"
    PROJECT_DESCRIPTION: str = "المساعد الذكي لإدارة ومتابعة المشاريع والمتاجر الصغيرة"
    VERSION: str = "1.0.0"
    
    # Database config
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./khidma.db")
    
    # Gemini AI config
    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")
    GEMINI_MODEL: str = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    
    # Server config
    HOST: str = os.getenv("HOST", "127.0.0.1")
    PORT: int = int(os.getenv("PORT", "8000"))
    DEBUG: bool = os.getenv("DEBUG", "True").lower() in ("true", "1", "yes")

settings = Settings()
