# خِدمة - Khidma Smart Assistant Package
__version__ = "1.0.0"
