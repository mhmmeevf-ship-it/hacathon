import os
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, Depends, Request, Form, HTTPException, status
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.config import settings
from app.database import engine, Base, get_db
from app.models import Customer, Order, Transaction
from app.schemas import CustomerCreate, OrderCreate, TransactionCreate
from app.seed import seed_data_if_empty
from app import crud
from app.ai_service import analyze_business_performance

# Ensure tables exist and seed initial data
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=settings.PROJECT_NAME,
    description=settings.PROJECT_DESCRIPTION,
    version=settings.VERSION
)

# Template configuration
BASE_DIR = Path(__file__).resolve().parent
TEMPLATES_DIR = BASE_DIR / "templates"
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))

# Ensure database is seeded on startup
@app.on_event("startup")
def on_startup():
    db = next(get_db())
    try:
        seed_data_if_empty(db)
    finally:
        db.close()


# ==========================================
# 1. Dashboard Routes (/)
# ==========================================
@app.get("/", response_class=HTMLResponse)
def get_dashboard(
    request: Request,
    msg: Optional[str] = None,
    msg_type: Optional[str] = "success",
    db: Session = Depends(get_db)
):
    stats = crud.get_dashboard_stats(db)
    recent_orders = crud.get_recent_orders(db, limit=8)
    customers = crud.get_customers(db)

    return templates.TemplateResponse(
        request=request,
        name="dashboard.html",
        context={
            "active_page": "dashboard",
            "stats": stats,
            "recent_orders": recent_orders,
            "customers": customers,
            "alert_msg": msg,
            "alert_type": msg_type
        }
    )


# ==========================================
# 2. Orders Management (/orders)
# ==========================================
@app.get("/orders", response_class=HTMLResponse)
def get_orders_page(
    request: Request,
    status: Optional[str] = None,
    msg: Optional[str] = None,
    msg_type: Optional[str] = "success",
    db: Session = Depends(get_db)
):
    orders = crud.get_orders(db, status=status)
    customers = crud.get_customers(db)
    stats = crud.get_dashboard_stats(db)

    return templates.TemplateResponse(
        request=request,
        name="orders.html",
        context={
            "active_page": "orders",
            "orders": orders,
            "customers": customers,
            "stats": stats,
            "current_status": status or "الكل",
            "alert_msg": msg,
            "alert_type": msg_type
        }
    )

@app.post("/orders")
def post_new_order(
    customer_id: Optional[str] = Form(None),
    new_customer_name: Optional[str] = Form(None),
    new_customer_phone: Optional[str] = Form(None),
    title: str = Form(...),
    amount: float = Form(...),
    status: str = Form("جديد"),
    db: Session = Depends(get_db)
):
    parsed_cust_id = int(customer_id) if customer_id and customer_id.strip() else None

    if not parsed_cust_id and (not new_customer_name or not new_customer_name.strip() or not new_customer_phone or not new_customer_phone.strip()):
        return RedirectResponse(
            url="/orders?msg=يرجى+اختيار+عميل+مسجل+أو+إدخال+اسم+وهاتف+العميل+الجديد&msg_type=error",
            status_code=status.HTTP_303_SEE_OTHER
        )

    if amount < 0:
        return RedirectResponse(
            url="/orders?msg=يرجى+إدخال+مبلغ+صحيح+أكبر+من+أو+يساوي+الصفر&msg_type=error",
            status_code=status.HTTP_303_SEE_OTHER
        )

    if not title or not title.strip():
        return RedirectResponse(
            url="/orders?msg=يرجى+إدخال+تفاصيل+ومواصفات+الطلب&msg_type=error",
            status_code=status.HTTP_303_SEE_OTHER
        )

    try:
        order_in = OrderCreate(
            customer_id=parsed_cust_id,
            new_customer_name=new_customer_name,
            new_customer_phone=new_customer_phone,
            title=title,
            amount=amount,
            status=status
        )
        created = crud.create_order(db, order_in)
        return RedirectResponse(
            url=f"/orders?msg=تم+إنشاء+الطلب+%23{created.id}+بنجاح&msg_type=success",
            status_code=status.HTTP_303_SEE_OTHER
        )
    except Exception as e:
        return RedirectResponse(
            url=f"/orders?msg=خطأ:+{str(e)}&msg_type=error",
            status_code=status.HTTP_303_SEE_OTHER
        )

@app.post("/orders/{order_id}/status")
def post_order_status(
    order_id: int,
    status: str = Form(...),
    db: Session = Depends(get_db)
):
    try:
        updated = crud.update_order_status(db, order_id, status)
        if not updated:
            return RedirectResponse(
                url="/orders?msg=الطلب+غير+موجود&msg_type=error",
                status_code=status.HTTP_303_SEE_OTHER
            )
        msg_suffix = " وتم تسجيل الإيراد تلقائياً في السجل المالي" if status == "مكتمل" else ""
        return RedirectResponse(
            url=f"/orders?msg=تم+تحديث+حالة+الطلب+%23{order_id}+إلى+{status}{msg_suffix}&msg_type=success",
            status_code=status.HTTP_303_SEE_OTHER
        )
    except Exception as e:
        return RedirectResponse(
            url=f"/orders?msg=خطأ:+{str(e)}&msg_type=error",
            status_code=status.HTTP_303_SEE_OTHER
        )


# ==========================================
# 3. Customers Management (/customers)
# ==========================================
@app.get("/customers", response_class=HTMLResponse)
def get_customers_page(
    request: Request,
    search: Optional[str] = None,
    msg: Optional[str] = None,
    msg_type: Optional[str] = "success",
    db: Session = Depends(get_db)
):
    customers = crud.get_customers(db, search=search)
    return templates.TemplateResponse(
        request=request,
        name="customers.html",
        context={
            "active_page": "customers",
            "customers": customers,
            "search": search,
            "alert_msg": msg,
            "alert_type": msg_type
        }
    )

@app.post("/customers")
def post_new_customer(
    name: str = Form(...),
    phone: str = Form(...),
    notes: Optional[str] = Form(None),
    db: Session = Depends(get_db)
):
    if not name or not name.strip() or not phone or not phone.strip():
        return RedirectResponse(
            url="/customers?msg=يرجى+إدخال+اسم+العميل+ورقم+الجوال&msg_type=error",
            status_code=status.HTTP_303_SEE_OTHER
        )

    try:
        c_in = CustomerCreate(name=name, phone=phone, notes=notes)
        crud.create_customer(db, c_in)
        return RedirectResponse(
            url=f"/customers?msg=تم+حفظ+العميل+{name}+بنجاح&msg_type=success",
            status_code=status.HTTP_303_SEE_OTHER
        )
    except Exception as e:
        return RedirectResponse(
            url=f"/customers?msg=خطأ:+{str(e)}&msg_type=error",
            status_code=status.HTTP_303_SEE_OTHER
        )


# ==========================================
# 4. Financials (/finance)
# ==========================================
@app.get("/finance", response_class=HTMLResponse)
def get_finance_page(
    request: Request,
    msg: Optional[str] = None,
    msg_type: Optional[str] = "success",
    db: Session = Depends(get_db)
):
    stats = crud.get_dashboard_stats(db)
    transactions = crud.get_transactions(db)

    return templates.TemplateResponse(
        request=request,
        name="finance.html",
        context={
            "active_page": "finance",
            "stats": stats,
            "transactions": transactions,
            "alert_msg": msg,
            "alert_type": msg_type
        }
    )

@app.post("/finance")
def post_transaction(
    type: str = Form(...),
    category: Optional[str] = Form(None),
    amount: float = Form(...),
    description: Optional[str] = Form(None),
    db: Session = Depends(get_db)
):
    if amount <= 0:
        return RedirectResponse(
            url="/finance?msg=يجب+أن+يكون+المبلغ+أكبر+من+الصفر&msg_type=error",
            status_code=status.HTTP_303_SEE_OTHER
        )

    if type not in ["مبيعات", "مصروفات"]:
        return RedirectResponse(
            url="/finance?msg=نوع+العملية+يجب+أن+يكون+إما+مبيعات+أو+مصروفات&msg_type=error",
            status_code=status.HTTP_303_SEE_OTHER
        )

    try:
        t_in = TransactionCreate(
            type=type,
            category=category,
            amount=amount,
            description=description
        )
        crud.create_transaction(db, t_in)
        return RedirectResponse(
            url=f"/finance?msg=تم+تسجيل+عملية+{type}+بمبلغ+{amount}+ر.س+بنجاح&msg_type=success",
            status_code=status.HTTP_303_SEE_OTHER
        )
    except Exception as e:
        return RedirectResponse(
            url=f"/finance?msg=خطأ:+{str(e)}&msg_type=error",
            status_code=status.HTTP_303_SEE_OTHER
        )


# ==========================================
# 5. AI Smart Assistant (/ai-assistant)
# ==========================================
@app.get("/ai-assistant", response_class=HTMLResponse)
def get_ai_assistant_page(
    request: Request,
    db: Session = Depends(get_db)
):
    stats = crud.get_dashboard_stats(db)
    ai_result = analyze_business_performance(db)

    return templates.TemplateResponse(
        request=request,
        name="ai_assistant.html",
        context={
            "active_page": "ai",
            "stats": stats,
            "ai_result": ai_result
        }
    )


# ==========================================
# JSON REST API Endpoints (For automation & integrations)
# ==========================================
@app.get("/api/stats")
def api_stats(db: Session = Depends(get_db)):
    return crud.get_dashboard_stats(db)

@app.get("/api/orders")
def api_get_orders(status: Optional[str] = None, db: Session = Depends(get_db)):
    orders = crud.get_orders(db, status=status)
    return [
        {
            "id": o.id,
            "customer_id": o.customer_id,
            "customer_name": o.customer.name,
            "customer_phone": o.customer.phone,
            "title": o.title,
            "amount": o.amount,
            "status": o.status,
            "created_at": o.created_at.isoformat()
        }
        for o in orders
    ]

@app.post("/api/orders", status_code=201)
def api_create_order(data: OrderCreate, db: Session = Depends(get_db)):
    order = crud.create_order(db, data)
    return {"id": order.id, "title": order.title, "amount": order.amount, "status": order.status}

@app.get("/api/customers")
def api_get_customers(search: Optional[str] = None, db: Session = Depends(get_db)):
    return crud.get_customers(db, search=search)

@app.post("/api/customers", status_code=201)
def api_create_customer(data: CustomerCreate, db: Session = Depends(get_db)):
    cust = crud.create_customer(db, data)
    return {"id": cust.id, "name": cust.name, "phone": cust.phone}

@app.get("/api/transactions")
def api_get_transactions(db: Session = Depends(get_db)):
    txs = crud.get_transactions(db)
    return [
        {
            "id": t.id,
            "type": t.type,
            "category": t.category,
            "amount": t.amount,
            "description": t.description,
            "created_at": t.created_at.isoformat()
        }
        for t in txs
    ]

@app.post("/api/transactions", status_code=201)
def api_create_transaction(data: TransactionCreate, db: Session = Depends(get_db)):
    tx = crud.create_transaction(db, data)
    return {"id": tx.id, "type": tx.type, "amount": tx.amount}

@app.get("/api/ai-analyze")
def api_ai_analyze(db: Session = Depends(get_db)):
    return analyze_business_performance(db)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host=settings.HOST, port=settings.PORT, reload=settings.DEBUG)
