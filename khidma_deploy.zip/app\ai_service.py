import logging
from typing import Dict, Any, List
from sqlalchemy.orm import Session
from app.config import settings
from app.crud import get_dashboard_stats, get_orders, get_customers

logger = logging.getLogger(__name__)

def generate_business_summary_data(db: Session) -> Dict[str, Any]:
    """Generates structured metrics summary for the AI or fallback engine."""
    stats = get_dashboard_stats(db)
    all_orders = get_orders(db)
    customers = get_customers(db)

    # Sort customers by total spent
    top_customers = sorted(customers, key=lambda c: c["total_spent"], reverse=True)[:3]
    top_cust_summary = [
        f"{c['name']} (إجمالي المشتريات: {c['total_spent']} ر.س - عدد الطلبات: {c['orders_count']})"
        for c in top_customers
    ]

    recent_order_titles = [f"{o.title} ({o.amount} ر.س - {o.status})" for o in all_orders[:5]]

    return {
        "stats": stats,
        "total_revenue": stats["total_revenue"],
        "total_expenses": stats["total_expenses"],
        "net_profit": stats["net_profit"],
        "total_orders": stats["total_orders"],
        "active_orders": stats["active_orders"],
        "completed_orders": stats["completed_orders"],
        "top_customers": top_cust_summary,
        "recent_orders": recent_order_titles
    }

def get_deterministic_fallback_analysis(data: Dict[str, Any], note: str = "") -> Dict[str, Any]:
    """Generates a high-quality deterministic Arabic analysis if Gemini API is offline/unavailable."""
    stats = data["stats"]
    net_profit = stats["net_profit"]
    rev = stats["total_revenue"]
    exp = stats["total_expenses"]
    active = stats["active_orders"]

    # Calculate profit margin
    profit_margin = round((net_profit / rev * 100), 1) if rev > 0 else 0

    if net_profit > 0:
        financial_health = f"المشروع يحقق أداءً ربحياً إيجابياً بصافي ربح قدره {net_profit:,.2f} ر.س وهامش ربح تقريبي {profit_margin}%."
    elif net_profit == 0:
        financial_health = "المشروع حالياً في نقطة التعادل المالي (المبيعات تعادل المصروفات تماماً)."
    else:
        financial_health = f"تنبيه مالي: المصروفات الحالية تفوق الإيرادات بعجز مالي قدره {abs(net_profit):,.2f} ر.س. يتطلب ضبط التكاليف فوراً."

    # Generate 3 deterministic smart Arabic recommendations
    rec1 = (
        "تسريع تسليم الطلبات النشطة: لديك حالياً "
        f"{active} طلبات قيد التنفيذ أو جديدة. تحويلها إلى «مكتمل» سيعزز التدفق النقدي المباشر فوراً."
    ) if active > 0 else "تنشيط قنوات البيع: ليس لديك طلبات نشطة حالياً، أطلق عرضاً ترويجياً لجذب عملاء جدد."

    rec2 = (
        f"مراقبة بنود المصروفات: تم تسجيل مصروفات تشغيلية بقيمة {exp:,.2f} ر.س. "
        "راجع تكلفة المواد الخام والمشتريات الدورية لتحسين هامش الربحية بنسبة 5-10%."
    )

    rec3 = (
        "مكافأة العملاء الأكثر إنفاقاً: عزز العلاقة مع أهم عملائك عبر تقديم عروض حصرية وخدمة ذات أولوية لضمان تكرار الشراء."
    )

    return {
        "ai_powered": False,
        "model_used": "المحرك الذكي الداخلي (قواعد أعمال حتمية)",
        "status_notice": note or "تم توليد التقرير بواسطة المحرك الحسابي الداخلي لـ «خِدمة».",
        "financial_health": financial_health,
        "recommendations": [rec1, rec2, rec3],
        "full_text": f"""### ملخص أداء المنشأة
- **الحالة المالية:** {financial_health}
- **حركة الطلبات:** إجمالي الطلبات المسجلة {stats['total_orders']} طلب، منها {stats['active_orders']} طلبات نشطة تحتاج متابعة.
- **الإيرادات:** {rev:,.2f} ر.س مقابل مصروفات قدرها {exp:,.2f} ر.س.

### التوصيات التشغيلية الثلاث:
1. **{rec1}**
2. **{rec2}**
3. **{rec3}**"""
    }

def analyze_business_performance(db: Session) -> Dict[str, Any]:
    """Analyzes business data using google-genai SDK (gemini-2.5-flash) with graceful fallback."""
    data = generate_business_summary_data(db)
    api_key = (settings.GEMINI_API_KEY or "").strip()

    # Fallback early if API key is not configured
    if not api_key or api_key == "your_gemini_api_key_here":
        return get_deterministic_fallback_analysis(
            data,
            note="💡 تنبيه: لم يتم تعيين مفتاح GEMINI_API_KEY في ملف .env. تم تشغيل المحرك الذكي الداخلي بنجاح دون أي تعطل."
        )

    try:
        from google import genai
        from google.genai import types

        client = genai.Client(api_key=api_key)

        system_instruction = (
            "أنت مستشار أعمال خبير ومحترف متخصص في توجيه وتنمية المتاجر والمشاريع الصغيرة. "
            "دورك تحليل الأداء المالي والتشغيلي للمتجر بدقة واحترافية، وتحديد نقاط القوة ومكامن الهدر أو العجز المالي، "
            "ثم تقديم بالضبط ثلاث (3) نصائح تشغيلية مركزة ومباشرة وقابلة للتطبيق الفوري لزيادة الأرباح وتحسين الكفاءة. "
            "التزم باللغة العربية الفصحى السلسة والمحفزة، واستخدم تنسيق Markdown أنيق وواضح مع العناوين والنقاط."
        )

        user_content = f"""
إليك بيانات النشاط التجاري الحالية لمتجرنا:
- إجمالي الإيرادات المسجلة (المبيعات): {data['total_revenue']} ريال سعودي
- إجمالي المصروفات التشغيلية: {data['total_expenses']} ريال سعودي
- صافي الربح الحالي: {data['net_profit']} ريال سعودي
- إجمالي الطلبات: {data['total_orders']} طلب
- الطلبات النشطة (جديد أو قيد التنفيذ): {data['active_orders']} طلب
- الطلبات المكتملة: {data['completed_orders']} طلب
- قائمة أهم العملاء ومشترياتهم: {', '.join(data['top_customers']) if data['top_customers'] else 'لا يوجد عملاء بعد'}
- عينة من أحدث الطلبات: {', '.join(data['recent_orders']) if data['recent_orders'] else 'لا توجد طلبات بعد'}

المطلوب:
1. تحليل موجز ومحدد للوضع المالي والتشغيلي (فقرة واحدة مركزة تشمل تقييم الربحية والنشاط).
2. بالضبط 3 توصيات تشغيلية مرقمة وقابلة للتنفيذ الفوري، تركز على رفع الإيرادات، إدارة المصروفات، وتنشيط المبيعات.
"""

        response = client.models.generate_content(
            model=settings.GEMINI_MODEL,
            contents=user_content,
            config=types.GenerateContentConfig(
                system_instruction=system_instruction,
                temperature=0.3,
            )
        )

        analysis_text = response.text or ""
        if not analysis_text.strip():
            raise ValueError("رد خالي من خدمة Gemini")

        return {
            "ai_powered": True,
            "model_used": f"Google Gemini ({settings.GEMINI_MODEL})",
            "status_notice": "✨ تم إعداد هذا التحليل المالي والتشغيلي بالذكاء الاصطناعي بواسطة Gemini 2.5 Flash.",
            "full_text": analysis_text
        }

    except Exception as e:
        logger.warning(f"Gemini API failure handled gracefully: {e}")
        error_msg = f"تعذر استدعاء Gemini API ({str(e)[:90]}). تم تفعيل المحرك التحليلي الداخلي كبديل فوري."
        return get_deterministic_fallback_analysis(data, note=error_msg)
